
@if(!$checkin)
<div></div>
@else
<div>{{$checkin->date}}</div>
@endif