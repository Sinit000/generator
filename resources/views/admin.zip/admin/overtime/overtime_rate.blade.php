@if($ot_rate)
    <p>${{$ot_rate}}</p>
@else
    <p>$0</p>
@endif