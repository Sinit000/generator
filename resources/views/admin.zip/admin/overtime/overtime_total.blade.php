@if($total_ot)
    <p>${{$total_ot}}</p>
@else
    <p>$0</p>
@endif