<input type="checkbox" name="check"
                value="{{ $id }}"/>