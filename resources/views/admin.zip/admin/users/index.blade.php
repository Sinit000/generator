@extends('admin.layouts.master')
@section('title', 'Employee')
@section('head','')
@section('css')
<link rel="stylesheet" href="{{ asset('public/backend/modules/datatables/datatables.min.css') }}">
    <style>
    .en[data="employee"]::before {
        content: 'Employee'
    }

    .kh[data="employee"]::before {
        content: 'បុគ្គលិក'
    }

    .en[data="create_data"]::before {
        content: 'Create Data'

    }

    .kh[data="create_data"]::before {
        content: 'បង្កើតទិន្នន័យ'
    }
    .en[data="img"]::before {
        content: 'Image'

    }

    .kh[data="img"]::before {
        content: 'រូបភាព'
    }
    .en[data="email"]::before {
        content: 'Email'

    }

    .kh[data="email"]::before {
        content: 'អុីម៉ែល'
    }
     .en[data="phone"]::before {
        content: 'Phone'

    }

    .kh[data="phone"]::before {
        content: 'លេខទូរសព្ទ័'
    }
     .en[data="position"]::before {
        content: 'Position'

    }

    .kh[data="position"]::before {
        content: 'តួនាទី'
    }
    .en[data="department"]::before {
        content: 'Department'

    }

    .kh[data="department"]::before {
        content: 'ដេប៉ាតេម៉ង់'
    }
    
    
    .en[data="action"]::before {
        content: 'Action'

    }
    .kh[data="action"]::before {
        content: 'សកម្មភាព'
    }
    .en[data="no"]::before {
        content: 'No'

    }
    .kh[data="no"]::before {
        content: 'ល.រ'
    }
    .en[data="user_name"]::before {
        content: 'Name'

    }
    .kh[data="user_name"]::before {
        content: 'ឈ្មោះ'
    }
    .en[data="dashboard"]::before {
        content: 'Name'

    }
    .kh[data="dashboard"]::before {
        content: 'ផ្ទាំងការងារ'
    }
    #language-family{
        font-family:Khmer OS Battambang;
    }
</style>
@endsection

@section('content')
<!-- Modal -->

<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1 data="employee" id="title-family" class="en"></h1>
            <!-- <h1>Employee Data</h1> -->
            <div class="section-header-breadcrumb">
               <div class="breadcrumb-item" >
                    <i class="fa fa-home" ></i>
                    <a href="{{ url('admin/dashboard') }}" data="dashboard" id="subtitle-family" class="en" ></a>
                </div>
            </div>
        </div>
        <!-- alert error -->
        @if (session('success'))
        <div class="alert alert-success alert-dismissible show fade">
            <div class="alert-body">
                <button class="close" data-dismiss="alert">
                    <span>×</span>
                </button>
                {!! session('success') !!}
            </div>
        </div>
        @endif
        <div class="section-body">
            <div class="card card-info">
                <div class="card-header">
                    <div class="ml-auto">
                        <a href="{{url('admin/user/create')}}" >
                            <p class="en btn btn-info "  data="create_data" id="subtitle-family"></p></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover table-bordered" id="user-table">
                            <thead class="thead-light">
                                <tr>
                                    <th > <p class="en" data="no" id="subtitle-family"></p></th>
                                    <th > <p class="en" data="img" id="subtitle-family"></p></th>
                                    <th ><p class="en" data="user_name" id="subtitle-family"></p>  </th>
                                    <th ><p class="en" data="email" id="subtitle-family"></p> </th>
                                    <th ><p class="en" data="phone" id="subtitle-family"></p>  </th>
                                    <th ><p class="en" data="position" id="subtitle-family"></p></th>
                                    <th ><p class="en" data="department" id="subtitle-family"></p></th>
                                    <th ><p class="en" data="action" id="subtitle-family"></p></th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@endsection

@section('js')
<script src="{{ asset('public/backend/modules/datatables/datatables.min.js') }}"></script>
<script src="{{ asset('public/backend/modules/sweetalert/sweetalert.min.js') }}"></script>

<script>
    checkLanguage()
    function checkLanguage() {
            langCode = localStorage.getItem("lang-code");
            if (!langCode) {
                langCode = "en";
                localStorage.setItem("lang-code", "en")
            }
            let needTranslates = [];
            if (langCode === "en") {
                needTranslates = [...document.getElementsByClassName('kh')];
                for (let n of needTranslates) {
                n.classList.replace("kh", "en")
                }
            } else {
                needTranslates = [...document.getElementsByClassName('en')];
                for (let n of needTranslates) {
                n.classList.replace("en", "kh")

                }
            }
        }
    // 
    $(document).ready(function() {
        // Setup AJAX CSRF
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // Initializing DataTable
        $('#user-table').DataTable({
            dom: 'Bfrtip',
            processing: true,
            serverSide: true,
            ajax: "{{url('admin/user')}}",
            columns: [


                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex',
                    orderable: false,
                    searchable: false
                },
                {
                    data: 'image',
                    name: 'image'

                },
                // {
                //     data: 'no',
                //     name: 'no'
                // },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'employee_phone',
                    name: 'employee_phone'
                },
                {
                    data: 'position.position_name',
                    name: 'position.position_name'
                },
                {
                    data: 'department.department_name',
                    name: 'department.department_name'
                },

                {
                    "data": null,
                    render: function(data, type, row) {

                        return `<div><a href="{{url('admin/user/details')}}/${row.id}"><button data-toggle="tooltip" data-original-title="View" data-id="${row.id}" class="btn btn-sm btn-icon btn-warning"  id="editBtn"><i class="fa fa-eye"></i></button></a>  <a href="{{url('admin/user/edit')}}/${row.id}"><button data-toggle="tooltip" data-original-title="Edit" data-id="${row.id}" class="btn btn-sm btn-icon btn-info"  id="editBtn"><i class="fa fa-edit"></i></button></a>   <button data-toggle="tooltip" data-original-title="Delete" data-id="${row.id}"  class="btn btn-sm btn-icon btn-danger" data-original-title="Delete"  id="deleteBtn"><i class="fa fa-trash-alt"></i></button></div>`
                    }
                },
                // {
                //     data: 'action',
                //     name: 'action',
                //     className: 'text-center',
                //     orderable: false,
                //     searchable: false
                // }
            ],
        });

        $('#user-table').DataTable().on('draw', function() {
            $('[data-toggle="tooltip"]').tooltip();
        });

        // Open Modal to Add new Category
        $('#btn-add').click(function() {
            $('#formModal').modal('show');
            $('.modal-title').html('Create Data');
            $('#company-form').trigger('reset');
            $('#btn-save').html('<i class="fas fa-check"></i> Simpan');
            $('#company-form').find('.form-control').removeClass('is-invalid is-valid');
            $('#btn-save').val('save').removeAttr('disabled');
        });

        // Store new company or update company

        //  Edit Category



        // Delete company
        $(document).on('click', '#deleteBtn', function() {
            var id = $(this).attr('data-id');
            console.log(id);
            swal("Warning!", "Are you sure you want to delete?", "warning", {
                buttons: {
                    cancel: "NO!",
                    ok: {
                        text: "Yes!",
                        value: "ok"
                    }
                },
            }).then((value) => {
                switch (value) {
                    case "ok":
                        $.ajax({
                            type: "DELETE",
                            url: "{{ url('admin/user/delete') }}" + '/' + id,
                            success: function(data) {
                                if (data.code == 0) {
                                    $('#user-table').DataTable().draw(false);
                                    $('#user-table').DataTable().on('draw', function() {
                                        $('[data-toggle="tooltip"]').tooltip();
                                    });

                                    swal({
                                        title: "Success!",
                                        text: "Data has been deleted successfully!",
                                        icon: "success",
                                        timer: 3000
                                    });
                                } else {
                                    swal({
                                        title: "Sorry!",
                                        text: data.message,
                                        icon: "error",
                                        timer: 3000
                                    });
                                }
                            },
                            error: function(data) {
                                swal({
                                    title: "Success!",
                                    text: "Data has been deleted successfully!",
                                    icon: "success",
                                    timer: 3000
                                });
                            }
                        });
                        break;

                    default:
                        swal({
                            title: "Oh Ya!",
                            text: "Data is not change",
                            icon: "info",
                            timer: 3000
                        });
                        break;
                }
            });
        });
    });
</script>
@endsection