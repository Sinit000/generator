<div class="form-button-action">
    <button data-toggle="tooltip" id="editBtn" class="btn btn-sm btn-icon btn-info" data-original-title="Edit" data-id="{{ $id }}"><i class="fa fa-edit"></i>
    </button>
    
</div>
