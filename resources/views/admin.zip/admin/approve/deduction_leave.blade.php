@if($leave_deduction)
    <p>${{$leave_deduction}}</p>
@else
    <p>$0</p>
@endif