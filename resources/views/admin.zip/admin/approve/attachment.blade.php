
@if($image_url)
    <img src="https://banban-hr.com/hotel/public/{{ $image_url }}" data-id="{{$id}}"   width="50" height="50" class="img-rounded"  />
@else

@endif