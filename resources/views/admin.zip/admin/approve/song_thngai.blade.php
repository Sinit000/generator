@if($request_type=="clear_ot")
    <p>Clear OT</p>
@else
    <p>Song Thngai</p>
@endif