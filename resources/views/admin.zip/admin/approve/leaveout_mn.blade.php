@if($type=="hour")
    <p>{{$duration}} hour</p>
@else
    <p>{{$duration}} mn</p>
@endif