<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Polycy</title>
</head>
<body>
<p><strong>Privacy Policy </strong></p>
<p><br></p>
<p>My App didn't store user location , we just get user's current location to compare with the another location for  qr code for check their attendance only. </p>
<p>We get the user's current location when they check their attendance only for other functions , we don't require their location </p>

<p><br></p>
<p><strong>For user information, we didn't share to other third parties </strong></p>
<!-- <p><strong>For user Information about this function ,visit this link <a href="">dd</a> </strong></p> -->
