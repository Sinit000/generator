<!-- General JS Scripts -->
<!-- <script src="https://demo.getstisla.com/assets/modules/jquery.min.js"></script> -->
<script src="{{ asset('public/backend/modules/jquery.min.js') }}"></script>
<!-- <script src="https://demo.getstisla.com/assets/modules/popper.js"></script> -->
<script src="{{ asset('public/backend/modules/popper.js') }}"></script>
<script src="{{ asset('public/backend/modules/tooltip.js') }}"></script>
<!-- <script src="https://demo.getstisla.com/assets/modules/popper.js"></script> -->
<!-- <script src="https://demo.getstisla.com/assets/modules/tooltip.js"></script> -->
<!-- <script src="https://demo.getstisla.com/assets/modules/bootstrap/js/bootstrap.min.js"></script> -->
<script src="{{ asset('public/backend/modules/bootstrap/js/bootstrap.min.js') }}"></script>
<!-- <script src="{{ asset('backend/modules/bootstrap/nicescroll/jquery.nicescroll.min.js') }}"></script> -->
<script src="{{ asset('public/backend/modules/moment.min.js') }}"></script>
<!-- important when munu has list -->
<!-- <script src="https://demo.getstisla.com/assets/modules/nicescroll/jquery.nicescroll.min.js"></script> -->
 <!-- <script src="https://demo.getstisla.com/assets/modules/moment.min.js"></script> -->
<!-- <script src="{{ asset('backend/modules/bootstrap/nicescroll/jquery.nicescroll.min.js') }}"></script>  -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js" integrity="sha512-zMfrMAZYAlNClPKjN+JMuslK/B6sPM09BGvrWlW+cymmPmsUT1xJF3P4kxI3lOh9zypakSgWaTpY6vDJY/3Dig==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
<script src="{{ asset('public/backend/js/jquery.nicescroll.min.js') }}"></script>
<!-- <script src="https://demo.getstisla.com/assets/js/stisla.js"></script> -->
<script src="{{ asset('public/stisla.js') }}"></script>
<script src="{{ asset('public/js/function.js') }}"></script>


@yield('js')

<!-- Template JS File -->

<script src="{{ asset('public/scripts.js') }}"></script>
<script src="{{ asset('public/custom.js') }}"></script>
<!-- <script src="https://demo.getstisla.com/assets/js/scripts.js"></script>
<script src="https://demo.getstisla.com/assets/js/custom.js"></script> -->


