<h3 style="color:white;" >
   @yield('head')
</h3>