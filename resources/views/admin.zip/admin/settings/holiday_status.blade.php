
 @if($status=='pending')
 <div><p style="background: #5DADE2;border-radius: 15px;width: 100px;height: 30px;text-align: center;color:#FFFFFF;">Pending</p></div>
@else
<div><p style="background: #f44336;border-radius: 15px;width: 100px;height: 30px;text-align: center;color:#FFFFFF;">Compeleted</p></div>
@endif